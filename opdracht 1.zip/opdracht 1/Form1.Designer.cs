﻿namespace opdracht_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            VeranderMijKnop = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // VeranderMijKnop
            // 
            VeranderMijKnop.Image = (Image)resources.GetObject("VeranderMijKnop.Image");
            VeranderMijKnop.Location = new Point(36, 42);
            VeranderMijKnop.Name = "VeranderMijKnop";
            VeranderMijKnop.Size = new Size(200, 107);
            VeranderMijKnop.TabIndex = 0;
            VeranderMijKnop.UseVisualStyleBackColor = true;
            VeranderMijKnop.Click += VeranderMijKnop_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-1, 19);
            label1.Name = "label1";
            label1.Size = new Size(261, 15);
            label1.TabIndex = 1;
            label1.Text = "klik op het SMC logo om het te laten verdwijnen";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(333, 76);
            label2.Name = "label2";
            label2.Size = new Size(199, 15);
            label2.TabIndex = 2;
            label2.Text = "nu kan hij niet meer terug komen lol";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(284, 161);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(VeranderMijKnop);
            Name = "Form1";
            Text = "school.delete.X3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button VeranderMijKnop;
        private Label label1;
        private Label label2;
    }
}
