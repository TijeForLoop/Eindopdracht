using System;
using System.Windows.Forms;
using System.Timers;

namespace opdracht_1
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.Timer timer;

        public Form1()
        {
            InitializeComponent();
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 3000; // 3 seconden
            timer.Tick += Timer_Tick;
        }

        private void VeranderMijKnop_Click(object sender, EventArgs e)
        {
            VeranderMijKnop.Size = new System.Drawing.Size(0, 0);
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            this.Size = new System.Drawing.Size(600, 200);
            timer.Stop();
        }
    }
}
