namespace naamtest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void okbutton_Click(object sender, EventArgs e)
        {
            WelkomLabel.Text = "Welkom, " + NaamTextBox.Text + "!";
            this.Width = 500;
            this.Height = 200;
            okbutton.Location = new Point(150, 100);
            okbutton.Font = new Font("Calibri", 11);
        }
    }
}
