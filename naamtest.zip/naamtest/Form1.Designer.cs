﻿namespace naamtest
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            NaamTextBox = new TextBox();
            label1 = new Label();
            okbutton = new Button();
            WelkomLabel = new Label();
            SuspendLayout();
            // 
            // NaamTextBox
            // 
            NaamTextBox.AccessibleName = "NaamTextBox";
            NaamTextBox.BackColor = SystemColors.ControlLightLight;
            NaamTextBox.ForeColor = SystemColors.WindowText;
            NaamTextBox.Location = new Point(159, 31);
            NaamTextBox.Name = "NaamTextBox";
            NaamTextBox.Size = new Size(100, 23);
            NaamTextBox.TabIndex = 0;
            NaamTextBox.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(25, 31);
            label1.Name = "label1";
            label1.Size = new Size(128, 20);
            label1.TabIndex = 1;
            label1.Text = "Wat is je naam? :3";
            // 
            // okbutton
            // 
            okbutton.Location = new Point(158, 89);
            okbutton.Name = "okbutton";
            okbutton.Size = new Size(75, 23);
            okbutton.TabIndex = 2;
            okbutton.Text = "okie dokie!";
            okbutton.UseVisualStyleBackColor = true;
            okbutton.Click += okbutton_Click;
            // 
            // WelkomLabel
            // 
            WelkomLabel.AccessibleName = "WelkomLabel";
            WelkomLabel.AutoSize = true;
            WelkomLabel.Location = new Point(32, 130);
            WelkomLabel.Name = "WelkomLabel";
            WelkomLabel.Size = new Size(0, 15);
            WelkomLabel.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(529, 218);
            Controls.Add(WelkomLabel);
            Controls.Add(okbutton);
            Controls.Add(label1);
            Controls.Add(NaamTextBox);
            Name = "Form1";
            Text = "naam plz :D";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox NaamTextBox;
        private Label label1;
        private Button okbutton;
        private Label WelkomLabel;
    }
}
